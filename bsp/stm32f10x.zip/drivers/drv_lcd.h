#ifndef __DRV_LCD_H__
#define __DRV_LCD_H__		

#include <rtdevice.h>
#include <rthw.h>
					
#include <stm32f10x.h>

#include "stdlib.h"
#include "font.h"  
	
int rt_lcd_init(void);

#endif  
	 
	 



